
let userName=document.getElementById("name");
let passWord=document.getElementById("pass");
let indication1=document.getElementById("p1");
let indication2=document.getElementById("p2");

let form = document.getElementById('form')

form.addEventListener('submit', login)

function login(){
    
    if(userName.value==""){
        userName.focus();
        userName.style.border="2px solid red";
        indication1.innerHTML="Enter valid Username";
    }
    else{
        indication1.innerHTML="";
        userName.style.border="";
    }
    if(passWord.value==""){
        passWord.focus();
        passWord.style.border="2px solid red";
        indication2.innerHTML="Enter a valid Password";
    }
    else{
        indication2.innerHTML="";
        passWord.style.border="";
    }
    
    if(localStorage.getItem("box2")===userName.value && localStorage.getItem("box5")=== passWord.value){
        
        alert("successfully submitted");
        

    }
    else{
        
        userName.style.border="2px solid red";
        indication1.innerHTML="enter registered name";
        passWord.style.border="2px solid red";
        indication2.innerHTML="enter registered password";
        return false;
        
    
       }
 
}
function logout(){
    localStorage.removeItem("box2");
    localStorage.removeItem("box5")
}





