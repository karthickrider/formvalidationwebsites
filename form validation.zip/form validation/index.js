function validate(){
    var box1=document.getElementById("name");
    var box2=document.getElementById("user");
    var box3=document.getElementById("phone");
    var box4=document.getElementById("email");
    var box5=document.getElementById("pass");
    if(box1.value==""){
        document.getElementById("p1").innerHTML="Name is Must";
        box1.focus();
        box1.style.border="2px solid red";
        return false;
    }
    else{
        document.getElementById("p1").innerHTML="";
        box1.style.border="none";
    }
    if(box1.value.length>10){
        document.getElementById("p1").innerHTML="Name is Too Large";
        box1.focus();
        box1.style.border="2px solid red";
        return false;

    }
    else{
        document.getElementById("p1").innerHTML="";
        box1.style.border="none";
    }
    if(box2.value==""){
        document.getElementById("p2").innerHTML="Username is Must";
        box2.focus();
        box2.style.border="2px solid red";
        return false;

    }
    else{
        document.getElementById("p2").innerHTML="";
        box2.style.border="none";
        localStorage.setItem('box2',box2.value);
    }
    if(box2.value>15){
        document.getElementById("p2").innerHTML="Username is Too Large";
        box2.focus();
        box2.style.border="2px solid red";
        return false;
    }
    else{
        document.getElementById("p2").innerHTML="";
        box2.style.border="none";
    }
    if(box3.value=="" || box3.value.length>10 || box3.value.length<10 || isNaN(box3.value)){
        document.getElementById("p3").innerHTML="Enter Valid Phone Number";
        box3.focus();
        box3.style.border="2px solid red";
        return false;

    }
    else{
        document.getElementById("p3").innerHTML="";
        box3.style.border="none";
        
    }
    if(box4.value==""){
        document.getElementById("p4").innerHTML="Email is Must";
            box4.focus();
            box4.style.border="2px solid red";
            return false;
    
    
    }
    else{
        document.getElementById("p4").innerHTML="";
        box4.style.border="none";
    }
    if(box5.value=="" || box5.value.length<8){
        document.getElementById("p5").innerHTML="Password is Must";
            box5.focus();
            box5.style.border="2px solid red";
            return false;
    }
    else{
        document.getElementById("p5").innerHTML="";
        box5.style.border="none";
        localStorage.setItem('box5',box5.value);
    }
    

    
    
}


